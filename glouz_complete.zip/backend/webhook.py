from flask import Flask, request, jsonify
import hmac, hashlib, os

app = Flask(__name__)

INFINITEPAY_SECRET = os.environ.get('INFINITEPAY_SECRET','sua_chave_secreta_aqui')

@app.route('/webhook', methods=['POST'])
def webhook():
    # exemplo simples: verificar header 'X-Signature' (ajuste conforme InfinitePay real)
    signature = request.headers.get('X-Signature','')
    payload = request.get_data()
    expected = hmac.new(INFINITEPAY_SECRET.encode(), payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        return jsonify({'error':'invalid signature'}), 400
    data = request.json
    # processar evento
    print('Evento recebido:', data)
    # atualizar pedido no banco (exemplo)
    return jsonify({'status':'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
