import React, {useState} from 'react'

export default function App(){
  const products = [
    {id:1,title:'Brinco Argola Minimal',price:199},
    {id:2,title:'Colar Fio Delicado',price:249},
    {id:3,title:'Pulseira Elo',price:179}
  ];
  const [cart,setCart] = useState([]);
  const addToCart = (p) => setCart(prev=>[...prev,{...p,qty:1}]);
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="max-w-5xl mx-auto p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-amber-700">Glouz Acessórios</h1>
        <div>Cart: {cart.length}</div>
      </header>

      <main className="max-w-5xl mx-auto p-6">
        <section className="grid md:grid-cols-3 gap-6">
          {products.map(p=>(
            <article key={p.id} className="bg-white p-4 rounded-lg shadow">
              <div className="h-48 bg-gradient-to-br from-white to-gray-100 flex items-center justify-center rounded">{p.title}</div>
              <h3 className="mt-3 font-semibold">{p.title}</h3>
              <div className="text-amber-700 font-bold mt-1">R$ {p.price.toFixed(2).replace('.',',')}</div>
              <button className="mt-3 px-3 py-2 bg-amber-700 text-white rounded" onClick={()=>addToCart(p)}>Adicionar</button>
            </article>
          ))}
        </section>
      </main>

      <footer className="max-w-5xl mx-auto p-6 text-center text-sm text-gray-500">
        Demo Wireframe — sem integração real. Siga README para deploy e integração InfinitePay.
      </footer>
    </div>
  )
}
